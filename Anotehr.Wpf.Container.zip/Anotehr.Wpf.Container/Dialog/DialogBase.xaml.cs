﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using CommunityToolkit.Mvvm.DependencyInjection;

namespace AnotherEye.Base.Dialog
{
    /// <summary>
    /// DialogBase.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DialogBase : Window
    {
        private bool _positioned = false;
        private readonly StartPosition _startPosition;
        public DialogBase(StartPosition startPosition)
        {
            InitializeComponent();
            _startPosition = startPosition;
        }


        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Control content = dialogContent.Content as Control ?? throw new ArgumentNullException("ContentControls Content is not UserControl. should be UserControl");

        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);

            if (!_positioned)
            {
                SetStartPosition(_startPosition);
                //AnimateWindowSize(Width, Height);
                _positioned = true;
                Opacity = 1;
            }
        }

        private void SetStartPosition(StartPosition startPosition)
        {
            Point relativePos = Mouse.GetPosition(this); // WPF 상대좌표
            Point absolutePos = this.PointToScreen(relativePos); // 절대좌표로 변환

            switch (startPosition)
            {
                case StartPosition.Center:
                    dialogContent.RenderTransformOrigin = new Point(0.5, 0.5);
                    double screenWidth = SystemParameters.PrimaryScreenWidth;
                    double screenHeight = SystemParameters.PrimaryScreenHeight;
                    this.Left = (screenWidth / 2) - (Width / 2);
                    this.Top = (screenHeight / 2) - (Height / 2);
                    break;
                case StartPosition.Left:
                    dialogContent.RenderTransformOrigin = new Point(0, 0.5);
                    this.Left = absolutePos.X;
                    this.Top = absolutePos.Y - Height / 2;
                    break;
                case StartPosition.Right:
                    dialogContent.RenderTransformOrigin = new Point(1, 0.5);
                    this.Left = absolutePos.X - Width;
                    this.Top = absolutePos.Y - Height / 2;
                    break;
                case StartPosition.Top:
                    dialogContent.RenderTransformOrigin = new Point(0.5, 0);
                    this.Left = absolutePos.X - Width / 2;
                    this.Top = absolutePos.Y;
                    break;
                case StartPosition.Bottom:
                    dialogContent.RenderTransformOrigin = new Point(0.5, 1);
                    this.Left = absolutePos.X - Width/2;
                    this.Top = absolutePos.Y - Height;
                    break;
                case StartPosition.LeftUp:
                    dialogContent.RenderTransformOrigin = new Point(0, 0);
                    this.Left = absolutePos.X;
                    this.Top = absolutePos.Y;
                    break;
                case StartPosition.RightUp:
                    dialogContent.RenderTransformOrigin = new Point(1, 0);
                    this.Left = absolutePos.X - Width;
                    this.Top = absolutePos.Y;
                    break;
                case StartPosition.LeftDown:
                    dialogContent.RenderTransformOrigin = new Point(0, 1);
                    this.Left = absolutePos.X;
                    this.Top = absolutePos.Y - Height;
                    break;
                case StartPosition.RightDown:
                    dialogContent.RenderTransformOrigin = new Point(1, 1);
                    this.Left = absolutePos.X - Width;
                    this.Top = absolutePos.Y - Height;
                    break;
                default:
                    break;
            }
        }

        public void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                DragMove();
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void MaxiMizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void AnimateWindowSize(double targetWidth, double targetHeight)
        {
            var scaleXAnim = new DoubleAnimation
            {
                From = 0.5,
                To = 1.0,
                Duration = TimeSpan.FromSeconds(0.3),
                EasingFunction = new CircleEase { EasingMode = EasingMode.EaseOut }
            };

            var scaleYAnim = new DoubleAnimation
            {
                From = 0.5,
                To = 1.0,
                Duration = TimeSpan.FromSeconds(0.3),
                EasingFunction = new CircleEase { EasingMode = EasingMode.EaseOut }
            };

            var transform = dialogContent.RenderTransform as ScaleTransform;
            transform?.BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnim);
            transform?.BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnim);
        }


    }
}
