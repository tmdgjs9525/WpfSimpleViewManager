﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AnotherEye.Base.Core
{
    public interface IViewModelBase
    {

    }
}
